# Liver Classification Library

This library provides functions for data preprocessing, training, and evaluating models for liver disease classification.

## Installation
```bash
```
